package com.eureka.errekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErrekaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}

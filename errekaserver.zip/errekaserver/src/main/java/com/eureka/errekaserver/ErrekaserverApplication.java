package com.eureka.errekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErrekaserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErrekaserverApplication.class, args);
	}

}
